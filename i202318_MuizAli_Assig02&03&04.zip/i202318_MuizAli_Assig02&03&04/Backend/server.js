const express = require('express');
const app = express();
const port = 3000;

// Simulated blog data
const blogs = [
  { id: 1, title: 'Blog 1', content: 'Content for Blog 1' },
  { id: 2, title: 'Blog 2', content: 'Content for Blog 2' },
];

app.use(express.static('public'));

app.get('/api/blogs', (req, res) => {
  res.json(blogs);
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
